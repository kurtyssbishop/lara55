 @extends("layouts/page")

@section("mytitle","Home")