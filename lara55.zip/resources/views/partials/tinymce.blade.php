<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<script src="//cdn.tinymce.com/4/tinymce.min.js"></script>
 <script>tinymce.init({ 
     selector:'textarea', 
     plugins: "textcolor",
    toolbar: "forecolor backcolor" 
 });</script>
<?php