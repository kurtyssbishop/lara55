<div class="section-page-error">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12">
                        <!--S U C C E S S -->
                        <?php if(Session::has('flash_message')): ?>
                            <div class="alert alert-success">
                                <?php echo e(Session::get('flash_message')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="col-sm-12">
                        
                        <!--E R R O R-->
                        <?php if($errors->any()): ?>
                        <ul class="list-group" id="errors">
                            <h2 style="background-color:red;
                                color:white;
                                font-weight:bold;
                                padding:25px"
                                >
                                FORM ERRORS
                            </h2>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item"><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?> 
                        
                    </div>
                </div>
            </div>
        </div><!--END ERROR SECTION-->
		