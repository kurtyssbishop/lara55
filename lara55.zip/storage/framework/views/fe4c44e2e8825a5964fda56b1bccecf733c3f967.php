<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">

    <head>
        <?php echo $__env->make("partials.meta", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <title><?php echo $__env->yieldContent('mytitle'); ?></title>
        <?php echo $__env->yieldContent("head"); ?>
        <link rel="stylesheet" id="cssmain" type="text/css" href="<?php echo e(mix('css/app.css')); ?>" />
        <link href="https://cdn.rawgit.com/michalsnik/aos/2.1.1/dist/aos.css" rel="stylesheet">
        <!--link rel="stylesheet" href="/css/font-icons.css" type="text/css" /-->
        <!--link rel="stylesheet" href="/css/animate.css" type="text/css" /-->
        <?php echo $__env->yieldContent("css"); ?>
    </head>

    <body> 
        <?php echo $__env->yieldContent("preheader"); ?>

        <header>

            <?php echo $__env->yieldContent("postheader"); ?>
            <?php echo $__env->make("partials.logo", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->yieldContent("premenu"); ?>
            <?php echo $__env->make("partials.menu", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <?php echo $__env->yieldContent("postmenu"); ?>

        </header>
        <div class="clearfix"></div>
        <?php echo $__env->make("partials.error", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent("precontent"); ?>
        <!-----------------------------------MAIN BODY------------------------------>
      
       <?php echo $__env->yieldContent("content"); ?>  <!-- main content-->
        <!-----------------------------------END MAIN BODY------------------------------>

        <?php echo $__env->yieldContent("postcontent"); ?>
        <!-----------------------------------START FOOTER SECTION------------------------------>

        <footer id="footer" >
            <!-- Return to Top -->
            <a href="javascript:" id="return-to-top">
                <i class="fa fa-angle-up" aria-hidden="true"></i>
            </a>

            <?php echo $__env->yieldContent("footer"); ?>

        </footer>

        <!-----------------------------------END FOOTER SECTION------------------------------>
    <!--wrapper-->

    <!-- Go To Top
    ============================================= -->
    <div id="gotoTop" class="icon-angle-up"></div>

    <section class="js-wrapper">
        <script type="text/javascript" id="jsvendor"     src="<?php echo e(mix('js/vendor.js')); ?>"></script>
        <script type="text/javascript" id="jsmain"     src="<?php echo e(mix('js/app.js')); ?>"></script>
        <script src="https://cdn.rawgit.com/michalsnik/aos/2.1.1/dist/aos.js"></script>
        <?php echo $__env->make("partials.js", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent("js"); ?>
    </section>
    <!-----------------------------------END JS SECTION------------------------------>


</body>
</html>
