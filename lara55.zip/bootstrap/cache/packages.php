<?php return array (
  'fideloper/proxy' => 
  array (
    'providers' => 
    array (
      0 => 'Fideloper\\Proxy\\TrustedProxyServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
  ),
  'sven/artisan-view' => 
  array (
    'providers' => 
    array (
      0 => 'Sven\\ArtisanView\\ServiceProvider',
    ),
  ),
  'devmarketer/easynav' => 
  array (
    'providers' => 
    array (
      0 => 'DevMarketer\\EasyNav\\EasyNavServiceProvider',
    ),
    'aliases' => 
    array (
      'Nav' => 'DevMarketer\\EasyNav\\EasyNavFacade',
    ),
  ),
  'devmarketer/laraflash' => 
  array (
    'providers' => 
    array (
      0 => 'DevMarketer\\LaraFlash\\LaraFlashServiceProvider',
    ),
    'aliases' => 
    array (
      'LaraFlash' => 'DevMarketer\\LaraFlash\\LaraFlashFacade',
    ),
  ),
);